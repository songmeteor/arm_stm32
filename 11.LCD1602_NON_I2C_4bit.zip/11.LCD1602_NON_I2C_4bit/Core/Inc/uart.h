#ifndef __UART_H
#define __UART_H

#define COMMAND_NUMBER 20
#define COMMAND_LENGHT 40

#endif /* __UART_H */
