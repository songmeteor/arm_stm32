#include "main.h"


void delay_us(int us);
