#include "main.h"

void beep(int repeat);
void set_buzzer(int frequency);
void buzzer_main();
void PowerOnBuzzer();
void rrr(void);
